//addRequisition

import React, { useState, useEffect } from "react";
import { Helmet } from "react-helmet";
import axios from "axios";
import CurrencyInput from "react-currency-input-field";
import { useForm, Controller, set } from "react-hook-form";


const AddJobs = (props) => {
  const [values, setValues] = useState({
    requisitionId: create_UUID(),
    dateOfReq: "",
    closingDate: "",
    client: "",
    role: "",
    jobType: "",
    country: "",
    city: "",
    state: "",
    postalCode: "",
    min: "",
    max: "",
    jd: "",
    resp: "",
    skills: "",
    workType: "",
    elegibleCriteria: "",
    goodToAdd: "",
  });


  function create_UUID() {
    let value = Math.floor(1000 + Math.random() * 9000);
    return value;
  }


  const url = "http://localhost:9000/requisition";
  const RequisitionSubmit = async (e) => {
    e.preventDefault();
    await axios.post(url, { values });
    props.history.push("/app/administrator/jobs");
  };


  useEffect(() => {
    RequisitionSubmit();
  }, []);


  const onFormFieldChange = (e) => {
    setValues({
      ...values,
      [e.target.name]: e.target.value,
    });
  };

  // $(document).on('keyup', "input[data-type='currency']", function () {
  //   formatCurrency($(this));
  // });
  // $(document).on('blur', "input[data-type='currency']", function () {
  //   formatCurrency($(this), "blur");
  // });

  // function currencyNumber(n) {
  //   // format number 1000000 to 1,234,567
  //   // return n.replace(/\D/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",")
  //   // format number 1000000 to 12,34,567
  //   return n.replace(/\D/g, "").replace(/(\d+?)(?=(\d\d)+(\d)(?!\d))(\.\d+)?/g, "$1,");
  // }



  // function formatCurrency(input, blur) {
  //   var input_val = input.val();
  //   if (input_val === "") { return; }
  //   var original_len = input_val.length;
  //   var caret_pos = input.prop("selectionStart");
  //   if (input_val.indexOf(".") >= 0) {
  //     var decimal_pos = input_val.indexOf(".");
  //     var left_side = input_val.substring(0, decimal_pos);
  //     var right_side = input_val.substring(decimal_pos);
  //     left_side = currencyNumber(left_side);
  //     right_side = currencyNumber(right_side);
  //     if (blur === "blur") {
  //       right_side += "00";
  //     }
  //     right_side = right_side.substring(0, 2);
  //     input_val = left_side + "." + right_side;

  //   } else {
  //     input_val = currencyNumber(input_val);
  //     input_val = input_val;
  //     if (blur === "blur") {
  //       input_val += ".00";
  //     }
  //   }
  //   input.val(input_val);
  //   var updated_len = input_val.length;
  //   caret_pos = updated_len - original_len + caret_pos;
  //   input[0].setSelectionRange(caret_pos, caret_pos);
  // }


  return (
    <div className="page-wrapper">
      <Helmet>
        <title>Add Job - qBotica</title>
        <meta name="description" content="Login page" />
      </Helmet>
      {/* Page Content */}
      <div className="content container-fluid">
        <div className="row">
          <div className="col-md-8 offset-md-2">
            {/* Page Header */}
            <div className="page-header">
              <div className="row">
                <div className="col-sm-12">
                  <h3 className="page-title">Requisition</h3>
                </div>
              </div>
            </div>
            {/* /Page Header */}
            <form onSubmit={RequisitionSubmit}>
              <div className="row">
                <div className="col-sm-4">
                  <div className="form-group">
                    <label>
                      Requisition ID
                    </label>
                    <input
                      name="requisitionId"
                      className="form-control"
                      type="text"
                      value={values.requisitionId}
                      readOnly
                      onChange={onFormFieldChange}
                    />
                  </div>
                </div>
                <div className="col-sm-4">
                  <div className="form-group">
                    <label>Date of Requisition</label>
                    <input
                      name="dateOfReq"
                      value={values.dateOfReq}
                      className="form-control "
                      type="date"
                      onChange={onFormFieldChange}
                    />
                  </div>
                </div>
                <div className="col-sm-4">
                  <div className="form-group">
                    <label>Closing Date</label>
                    <input
                      name="closingDate"
                      value={values.closingDate}
                      className="form-control "
                      type="date"
                      onChange={onFormFieldChange}
                    />
                  </div>
                </div>
              </div>
              <div className="row">
                <div className="col-sm-4">
                  <div className="form-group">
                    <label>
                      Client
                    </label>
                    <input
                      name="client"
                      value={values.client}
                      className="form-control"
                      type="text"
                      onChange={onFormFieldChange}
                    />
                  </div>
                </div>
                <div className="col-sm-4">
                  <div className="form-group">
                    <label>Role</label>
                    <input
                      name="role"
                      value={values.role}
                      className="form-control "
                      type="text"
                      onChange={onFormFieldChange}
                    />
                  </div>
                </div>
                <div className="col-sm-4">
                  <div className="form-group">
                    <label>Job Type</label>
                    <select
                      name="country"
                      className="form-control3"
                      onChange={onFormFieldChange}
                      defaultValue={"DEFAULT"}
                    >
                      <option value="DEFAULT" disabled>
                        Select
                      </option>
                      <option>Full-time</option>
                      <option>Part-time</option>
                      <option>Intership</option>
                      {/* <option>Other</option> */}
                    </select>
                  </div>
                </div>
              </div>
              <div className="row">
                <div className="col-sm-6 col-md-6 col-lg-3">
                  <div className="form-group">
                    <label>Country</label>
                    <select
                      name="country"
                      className="form-control3"
                      onChange={onFormFieldChange}
                      defaultValue={"DEFAULT"}
                    >
                      <option value="DEFAULT" disabled>
                        Select
                      </option>
                      <option>India</option>
                      <option>USA</option>
                    </select>
                  </div>
                </div>
                <div className="col-sm-6 col-md-6 col-lg-3">
                  <div className="form-group">
                    <label>City</label>
                    <select
                      name="city"
                      className="form-control3"
                      onChange={onFormFieldChange}
                      defaultValue={"DEFAULT"}
                    >
                      <option value="DEFAULT" disabled>
                        Select
                      </option>
                      <option>Chennai</option>
                      <option>Bangalore</option>
                    </select>
                  </div>
                </div>
                <div className="col-sm-6 col-md-6 col-lg-3">
                  <div className="form-group">
                    <label>State</label>
                    <select
                      name="state"
                      className="form-control3"
                      onChange={onFormFieldChange}
                      defaultValue={"DEFAULT"}
                    >
                      <option value="DEFAULT" disabled>
                        Select
                      </option>
                      <option>Tamil Nadu</option>
                      <option>Karnataka</option>
                    </select>
                  </div>
                </div>
                <div className="col-sm-6 col-md-6 col-lg-3">
                  <div className="form-group">
                    <label>Postal Code</label>
                    <input
                      name="postalCode"
                      value={values.postalCode}
                      className="form-control"
                      type="number"
                      onChange={onFormFieldChange}
                    />
                  </div>
                </div>
              </div>
              <div className="row">
                <p>CTC</p>
                <div className="col-sm-6">
                  <div className="form-group">
                    <label>Minimun</label>
                    <CurrencyInput
                      name="min"
                      value={values.min}
                      className="form-control"
                      allowDecimals
                      decimalSeparator="."
                      prefix="₹"
                      intlConfig={{ locale: "en-IN", currency: "INR" }}
                      onChange={onFormFieldChange}
                    />
                  </div>
                </div>
                <div className="col-sm-6">
                  <div className="form-group">
                    <label>Maximum</label>
                    <input
                      name="max"
                      value={values.max}
                      className="form-control"
                      type="text"
                      data-type="currency"
                      onChange={onFormFieldChange}
                    />
                  </div>
                </div>
              </div>
              <div className="row">
                <div className="col-sm-12">
                  <div className="form-group">
                    <label>Roles & Responsibilities</label>
                    <textarea
                      name="resp"
                      value={values.resp}
                      className="form-control"
                      type="text"
                      onChange={onFormFieldChange}
                    />
                  </div>
                </div>
              </div>
              <div className="row">
                <div className="col-sm-12">
                  <div className="form-group">
                    <label>Desired skills</label>
                    <textarea
                      name="skills"
                      value={values.skills}
                      className="form-control"
                      type="text"
                      onChange={onFormFieldChange}
                    />
                  </div>
                </div>
              </div>
              <div className="row">
                <div className="col-sm-4">
                  <div className="form-group">
                    <label>Work Type</label>
                    <select
                      name="workType"
                      className="form-control3"
                      onChange={onFormFieldChange}
                      defaultValue={"DEFAULT"}
                    >
                      <option value="DEFAULT" disabled>
                        Select
                      </option>
                      <option>From Office</option>
                      <option>WFM</option>
                      <option>Hybrid</option>
                    </select>
                  </div>
                </div>
                <div className="col-sm-4">
                  <div className="form-group">
                    <label>Elegible Criteria</label>
                    <input
                      name="elegibleCriteria"
                      value={values.elegibleCriteria}
                      className="form-control "
                      type="text"
                      onChange={onFormFieldChange}
                    />
                  </div>
                </div>
                <div className="col-sm-4">
                  <div className="form-group">
                    <label>Good to add</label>
                    <input
                      name="goodToAdd"
                      value={values.goodToAdd}
                      className="form-control "
                      type="text"
                      onChange={onFormFieldChange}
                    />
                  </div>
                </div>
              </div>
              <div className="submit-section">
                <button className="btn btn-primary submit-btn">Save</button>
              </div>
            </form>
          </div>
        </div>
      </div>
      {/* /Page Content */}
    </div>
  );
};

export default AddJobs;
